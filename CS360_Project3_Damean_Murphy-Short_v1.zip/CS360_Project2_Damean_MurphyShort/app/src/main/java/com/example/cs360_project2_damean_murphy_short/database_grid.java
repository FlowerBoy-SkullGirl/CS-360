package com.example.cs360_project2_damean_murphy_short;

import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TableLayout;
import android.widget.TableRow;
import android.widget.TextView;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import com.google.android.material.floatingactionbutton.FloatingActionButton;

public class database_grid extends AppCompatActivity {
    TableLayout databaseTable;
    SQLiteDatabase dbW;
    SQLiteDatabase dbR;
    InventoryDBHelper dbHelper;

    String dbTableName = "inventory";
    String dbItemNameCol = "item_name";
    String dbQuantityCol = "quantity";

    //New inventory edit texts
    EditText newInvName;
    EditText newInvQuantity;
    Button confirmAddButton;

    protected int numRows = 1;
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.database_grid);

        newInvName = findViewById(R.id.newItemNameText);
        newInvQuantity = findViewById(R.id.newItemQuantityText);

        // Get the SQLite database instance
        dbHelper = new InventoryDBHelper(this);
        dbW = dbHelper.getWritableDatabase();
        dbR = dbHelper.getReadableDatabase();

        databaseTable = findViewById(R.id.DatabaseTableLayout);

        FloatingActionButton addItemButton = findViewById(R.id.addDatabaseItem);
        confirmAddButton = findViewById(R.id.confirm_add_button);
        Button sms_perm_button = findViewById(R.id.RequestSMSButton);
        Intent permissionLaunch = new Intent(this, sms_permission.class);

        //OnFloatingActionButtonClick, set all relevant views as visible
        addItemButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                newInvName.setVisibility(View.VISIBLE);
                newInvQuantity.setVisibility(View.VISIBLE);
                confirmAddButton.setVisibility(View.VISIBLE);
            }
        });

        //On click of confirm button, attempt to update database
        confirmAddButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                addDatabaseValues();
            }
        });

        //Request SMS activity launcher
        sms_perm_button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(permissionLaunch);
            }
        });

        // Test table row addition
        addTableRow(1, "Hat");
    }

    @Override
    protected void onDestroy()
    {
        dbHelper.close();
        super.onDestroy();
    }

    //SQLite helper subclass
    public class InventoryDBHelper extends SQLiteOpenHelper {
        public static final int DATABASE_VERSION = 1;
        public static final String DATABASE_NAME = "inventory.dbW";
        public InventoryDBHelper(Context context)
        {
            super(context, DATABASE_NAME, null, DATABASE_VERSION);
        }
        public void onCreate(SQLiteDatabase db) {
            String create_entries = "CREATE TABLE " + dbTableName + " ("
                    + "id INTEGER PRIMARY KEY AUTOINCREMENT, "
                    + dbItemNameCol + " TEXT,"
                    + dbQuantityCol + " INTEGER)";
            db.execSQL(create_entries);
        }
        public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion)
        {
            db.execSQL("DROP TABLE IF EXISTS " + dbTableName);
            onCreate(db);
        }
        public void onDowngrade(SQLiteDatabase db, int oldVersion, int newVersion)
        {
            onUpgrade(db, oldVersion, newVersion);
        }
    }

    public void addTableRow(int quantity, String name)
    {
        TableRow tr = new TableRow(this);

        TableLayout.LayoutParams quantityColParams = new TableLayout.LayoutParams(TableLayout.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        quantityColParams.setMarginStart((int) ( 20 * this.getResources().getDisplayMetrics().density));

        TableLayout.LayoutParams deleteColParams = new TableLayout.LayoutParams(TableLayout.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        deleteColParams.setMarginEnd((int) ( 20 * this.getResources().getDisplayMetrics().density));

        TableLayout.LayoutParams nameColParams = new TableLayout.LayoutParams(TableLayout.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        nameColParams.setMargins((int) ( 50 * this.getResources().getDisplayMetrics().density), 0, (int) (50 * this.getResources().getDisplayMetrics().density), 0);

        TextView amountTextView = new TextView(this);
        amountTextView.setText(String.valueOf(quantity));
        amountTextView.setLayoutParams(quantityColParams);

        TextView itemName = new TextView(this);
        itemName.setText(name);
        itemName.setLayoutParams(nameColParams);

        Button deleteButton = new Button(this);
        deleteButton.setText(R.string.Delete);
        deleteButton.setLayoutParams(deleteColParams);
        //deleteButton.setOnClick(DeleteRow);

        tr.addView(amountTextView);
        tr.addView(itemName);
        tr.addView(deleteButton);

        databaseTable.addView(tr);
        numRows++;
    }

    //Add SQLite database values
    public void addDatabaseValues()
    {
        TextView errorText = findViewById(R.id.errorMessageDatabaseEntry);
        //Reset error messaging
        errorText.setVisibility(View.INVISIBLE);
        String item_name = newInvName.getText().toString();
        int item_quantity;
        try {
            item_quantity = Integer.parseInt(newInvQuantity.getText().toString());
        }catch(Exception e){
            errorText.setVisibility(View.VISIBLE);
            return;
        }
        ContentValues inventory_item = new ContentValues();
        inventory_item.put(dbItemNameCol, item_name);
        inventory_item.put(dbQuantityCol, item_quantity);
        dbW.insert(dbTableName, null, inventory_item);

        //Set the edittexts as invisible after adding item
        newInvName.setVisibility(View.INVISIBLE);
        newInvQuantity.setVisibility(View.INVISIBLE);
        confirmAddButton.setVisibility(View.INVISIBLE);
    }
}
