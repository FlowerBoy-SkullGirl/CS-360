package com.example.cs360_project2_damean_murphy_short;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStreamReader;
import java.util.ArrayList;

public class login extends AppCompatActivity{
    //Make a class that holds pairs of strings for user authentication information
    class AuthPair{
        String user;
        String pass;
    };
    public static final String filen_auth_db = "auth_db";
    protected File auth_file;
    public ArrayList<String> fileContent = new ArrayList<String>();
    public Button login_Button;
    public Button create_user_button;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.login);

        //Find the login button views
        login_Button = findViewById(R.id.LoginButton);
        create_user_button = findViewById(R.id.CreateAccountButton);
        Button forgot_pass_button = findViewById(R.id.ForgotPasswordButton);

        AuthPair input_pair = new AuthPair();

        //Find the EditText views
        EditText userField = findViewById(R.id.usernameEditText);
        EditText passField = findViewById(R.id.passwordEditText);

        //Find the error message text view
        TextView error_message_view = findViewById(R.id.ErrorMessageText);

        //Create intent to launch database_grid activity on successful login
        Intent databaseLaunch = new Intent(this, database_grid.class);

        //check that the login database exists
        try {
            auth_file = new File(this.getFilesDir(), filen_auth_db);
            auth_file.createNewFile();
        } catch (Exception ex){
            System.exit(1);
        }

        //Set login button click listener
        //Set auth pair values to edittext content and compare to auth database
        login_Button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                boolean auth_passed = false;
                input_pair.user = userField.getText().toString();
                input_pair.pass = passField.getText().toString();
                readFileContents(auth_file);

                auth_passed = checkAuthMatch(fileContent, input_pair);
                //If authentication information matches, launch database activity, otherwise, show failed authentication message
                if (auth_passed)
                    startActivity(databaseLaunch);
                else
                    error_message_view.setText(R.string.failed_auth_message);
                    error_message_view.setVisibility(View.VISIBLE);
            }
        });

        //Append the information entered to the authentication database, login automatically on success
        create_user_button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                input_pair.user = userField.getText().toString();
                input_pair.pass = passField.getText().toString();
                if(appendAuthPairToFile(input_pair, auth_file)){
                    startActivity(databaseLaunch);
                }else{
                    error_message_view.setText(R.string.failed_create_message);
                    error_message_view.setVisibility(View.VISIBLE);
                }
            }
        });

        //Not currently implemented, display error message saying feature is unavailable
        forgot_pass_button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                error_message_view.setText(R.string.failed_change_pass_message);
                error_message_view.setVisibility(View.VISIBLE);
            }
        });
    }

    //Read file contents into an arraylist of string lines, return true if successful
    public boolean readFileContents(File file)
    {
        // Clear content before recreating list
        fileContent.clear();
        try{
            FileInputStream file_is = new FileInputStream(file);
            InputStreamReader is_reader = new InputStreamReader(file_is);
            BufferedReader buf_reader = new BufferedReader(is_reader);
            String line_str;
            while( (line_str = buf_reader.readLine()) != null)
            {
                fileContent.add(line_str);
            }
            //Close stream when finished
            file_is.close();
        }catch(Exception e){
            return false;
        }
        return true;
    }

    //Split file content strings into pairs of usernames and passwords delimited by commas
    //Compare to user input
    public boolean checkAuthMatch(ArrayList<String> file_content, AuthPair userInput)
    {
        if (userInput == null)
            return false;

        String [] str_buffer;
        AuthPair auth_buffer = new AuthPair();
        for (int i = 0; i < file_content.size(); i++)
        {
            str_buffer = file_content.get(i).split(",");
            auth_buffer.user = str_buffer[0];
            auth_buffer.pass = str_buffer[1];
            // If username and pass match, return true
            // If pass does not match, return early
            // If no match, return false
            if (auth_buffer.user.equals(userInput.user)){
                if (auth_buffer.pass.equals(userInput.pass))
                    return true;
                else
                    return false;
            }else
                continue;
        }
        return false;
    }

    //Turn an AuthPair object into a comma delimited string
    public String authPairToString(AuthPair ap)
    {
        if (ap == null)
            return "";
        return ap.user + ',' + ap.pass;
    }

    //Append new comma-delimited authentication information to the database file
    public boolean appendAuthPairToFile(AuthPair ap, File db_file)
    {
        if (ap == null || db_file == null)
            return false;
        //Open a stream for appending
        String append_line = authPairToString(ap) + '\n';
        try{
            FileOutputStream file_os = new FileOutputStream(db_file, true);
            file_os.write(append_line.getBytes());
            file_os.close();
            return true;
        }catch(Exception e){
            System.exit(1);
        }
        return false;
    }
}