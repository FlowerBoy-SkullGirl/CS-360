package com.example.cs360_project2_damean_murphy_short;

import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;

import androidx.activity.EdgeToEdge;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class sms_permission extends AppCompatActivity {

    public ActivityResultLauncher<String> requestPermissionLauncher;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_sms_permission);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        Button acceptButton = findViewById(R.id.AcceptButton);
        Button denyButton = findViewById(R.id.DenyButton);

        Intent databaseLaunch = new Intent(this, database_grid.class);

        requestPermissionLauncher = registerForActivityResult(new ActivityResultContracts.RequestPermission(), isGranted -> {
            if (isGranted){
                Log.d("Permissions granted", "User granted SMS permission");
            }else{
                Log.d("Permissions denied", "User denied SMS permission");
            }
        });

       //If user accepts SMS, prompt system dialog to grant permission, then return to database screen
        acceptButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                requestPermissionLauncher.launch("android.permission.SEND_SMS");
                startActivity(databaseLaunch);
            }
        });

        //If user denies SMS, return to database screen
        denyButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(databaseLaunch);
            }
        });
    }

    private boolean hasSMSPermissions()
    {
        String SMSPermission = "android.permission.SEND_SMS";
        if (ContextCompat.checkSelfPermission(this, SMSPermission) != PackageManager.PERMISSION_GRANTED) {
            if (ActivityCompat.shouldShowRequestPermissionRationale(this, SMSPermission)) {
                //showPermissionRationaleDialog();
            } else {
                requestPermissionLauncher.launch(SMSPermission);
            }
            return false;
        }
        return true;
    }
}